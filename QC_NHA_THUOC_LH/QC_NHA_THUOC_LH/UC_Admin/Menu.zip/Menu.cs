﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QC_NHA_THUOC_LH.UC_Admin
{
    public partial class Menu : Form
    {

        public Menu()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flowLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }
        private void sidebar_Click(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }
        bool sidebarExpand = true;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (sidebarExpand)
            {
                flowLayoutPanel2.Width -= 10;
                if (flowLayoutPanel2.Width <= 50)
                {
                    sidebarExpand = false;
                    timer1.Stop();
                }
            }
            else
            {
                flowLayoutPanel2.Width += 10;
                if (flowLayoutPanel2.Width >= 300)
                {
                    sidebarExpand = true;
                    timer1.Stop();
                }
            }
        }

        private void btnQuanLyNhanVien_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FormQuanNhanVien());
        }
        private Form currentChildForm;
        private void OpenChildForm(Form childForm)
        {
            // Đóng form con cũ nếu có
            if (currentChildForm != null)
                currentChildForm.Close();

            // Gán form con mới
            currentChildForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;

            // Xóa form con cũ ra khỏi panel chứa
            panelContainer.Controls.Clear();
            panelContainer.Controls.Add(childForm);
            panelContainer.Tag = childForm;

            childForm.BringToFront();
            childForm.Show();
        }

        private void btnQuanLyThuoc_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FormQuanLiThuoc());
        }

        private void btnQuanLiDonThuoc_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FormQuanLiDonThuoc());
        }

        private void btnNhaCungCap_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FormQuanLiNhaCungCap());
        }
        private void btnQuanLiKhoThuoc_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FormQuanLiKho());
        }
    }
}